cd $(cd `dirname $0`; pwd)

> nohup.out

nohup ./v2ray -config config.json &
